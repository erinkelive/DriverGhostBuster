
# 👻 Ghostware Manifesto 0.1

A digital declaration of freedom, risk, and responsibility for creators of chaos and seekers of truth.

---

## 🇬🇧 English

**Ghostware License 0.1**  
No warranty. No promise. No safe zone.  
You use, you test, you burn.  
Or maybe it works. Who knows.  
Use it if you wanna do it.  
Your risk. System damage!!! 👻💥

This software does not want to protect you. It wants to obey you.  
You are the root. Be worthy of it.

If it works, good.  
If it doesn't, better luck next reboot.

_Hack with heart. Break with reason. Share with soul._

---

## 🇧🇷 Português

**Licença Ghostware 0.1**  
Nenhuma garantia. Nenhuma promessa. Nenhuma zona segura.  
Você usa, você testa, você queima.  
Ou talvez funcione. Quem sabe.  
Use se quiser.  
Seu risco. Pode detonar seu sistema!!! 👻💥

Este programa não quer te proteger. Ele quer te obedecer.  
Você é root. Esteja à altura.

Se funcionar, ótimo.  
Se der ruim, boa sorte no próximo boot.

_Hackeie com coração. Quebre com lógica. Compartilhe com alma._

---

## 🇪🇸 Español

**Licencia Ghostware 0.1**  
Sin garantías. Sin promesas. Sin zona segura.  
Tú lo usas, tú lo pruebas, tú lo destruyes.  
O tal vez funcione. Nadie lo sabe.  
Úsalo si te atreves.  
Bajo tu propio riesgo. ¡Puede matar tu sistema! 👻💥

Este software no quiere salvarte. Quiere obedecerte.  
Tú eres root. Sé digno.

Si funciona, genial.  
Si no... reinicia y reza.

_Hackea con alma. Rompe con sentido. Comparte con fuego._
