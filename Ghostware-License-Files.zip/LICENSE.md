
# 🧾 Ghostware License 0.1

**No warranty. No promise. No safe zone.**  
You use, you test, you burn.  
Or maybe it works. Who knows.

---

This software is licensed under the **Ghostware License 0.1**, an experimental license designed for developers, hackers, and tinkerers who accept full responsibility over the code they execute.

**Permission is granted**, free of charge, to any person obtaining a copy of this software and associated files (the "Software"), to use, modify, merge, publish, distribute, and even break their system with it — subject to the following conditions:

## RULES OF GHOSTWARE:

1. **You are root. Be worthy of it.**
2. **No warranty** is provided, implied or assumed. None.
3. The authors are **not liable** for any damages, including total OS meltdown, loss of time, existential crisis, or BIOS possession.
4. This license **does not grant safety**, only freedom.
5. You are encouraged to:
   - Learn from the code
   - Improve it
   - Share it
   - Burn your system **only knowingly**
6. All use of the Software is **entirely at your own risk**.

---

If you don’t understand these terms, **don’t use this Software**.  
If you do — welcome, ghostbuster.

> "Hack with heart. Break with reason. Share with soul."  
> – Ghostware 0.1
