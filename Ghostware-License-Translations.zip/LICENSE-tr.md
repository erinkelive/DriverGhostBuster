
# 🧾 Ghostware Lisansı 0.1

**Garanti yok. Söz yok. Güvenli bölge yok.**  
Kullanırsın, test edersin, yakarsın.  
Belki çalışır, belki çalışmaz. Kim bilir?

---

Bu yazılım, kodlarıyla ne yaptığını bilen geliştiriciler ve hackerlar için tasarlanmış deneysel bir lisans olan **Ghostware License 0.1** altında lisanslanmıştır.

## GHOSTWARE KURALLARI:

1. Root sensin. Layık ol.
2. Hiçbir garanti verilmez.
3. Yazar hiçbir zarardan sorumlu değildir.
4. Bu lisans sana güvenlik vermez, özgürlük verir.
5. Tavsiye edilenler:
   - Koddan öğren
   - Geliştir
   - Paylaş
   - Bilinçli yak

Anlamadıysan, kullanma.  
Anladıysan, hoş geldin Ghostbuster 👻
