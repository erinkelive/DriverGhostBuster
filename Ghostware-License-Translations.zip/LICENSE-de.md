
# 🧾 Ghostware Lizenz 0.1

**Keine Garantie. Kein Versprechen. Keine sichere Zone.**  
Du benutzt es, du testest es, du brennst.  
Vielleicht funktioniert es. Vielleicht nicht. Wer weiß?

---

Diese Software unterliegt der **Ghostware License 0.1**, einer experimentellen Lizenz für Entwickler, Hacker und Neugierige, die bereit sind, die volle Verantwortung zu tragen.

## REGELN:

1. Du bist root. Sei es wert.
2. Keine Haftung, keine Sicherheit.
3. Autor haftet für nichts.
4. Du bekommst Freiheit, keine Versicherung.
5. Tu Folgendes:
   - Lerne aus dem Code
   - Verbessere ihn
   - Teile ihn
   - Zerstöre dein System — bewusst

Wenn du das nicht verstehst — benutze es nicht.  
Wenn du es verstehst — Willkommen, Ghostbuster. 👻
