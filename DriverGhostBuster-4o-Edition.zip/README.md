
# DriverGhostBuster (4o Edition)

A PowerShell tool to help Windows 11 users locate and remove ghost/leftover drivers from their system.

> Made by ChatGPT-4o with 💀 logic, tested by Enver with courage.

---

## ⚠️ DISCLAIMER

```
USE AT YOUR OWN RISK. THIS TOOL CAN DELETE CRITICAL DRIVERS.
DO NOT USE THIS IF YOU DON'T KNOW EXACTLY WHAT YOU ARE DOING.
```

---

## 🔧 Features

- Search for drivers by name/keyword
- Locate which `.INF` installed a `.SYS`
- Check if `.SYS` file still exists
- Detect related registry entries
- Remove driver via `pnputil`
- Delete `.SYS` files manually
- Export full list of installed drivers

---

## 💡 How to Run

1. Save the file `driver-ghostbuster.ps1`
2. Open PowerShell as Administrator
3. Run:

```powershell
Set-ExecutionPolicy RemoteSigned -Scope Process
.\driver-ghostbuster.ps1
```

---

## 📂 License

MIT-style permissive: use it, fork it, break your system at your own risk.

---  
Made with 💀 by ChatGPT-4o, inspired by Enver. Keep it free, keep it wild.
